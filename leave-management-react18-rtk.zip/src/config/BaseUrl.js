/* eslint-disable prettier/prettier */
export const managementJsonApi=`${process.env.REACT_APP_MANAGEMENT_API_URL}`
